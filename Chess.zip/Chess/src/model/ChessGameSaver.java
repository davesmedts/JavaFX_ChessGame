package model;

public class ChessGameSaver {

}
