package model;

public enum Color {
    WHITE, BLACK;
}
