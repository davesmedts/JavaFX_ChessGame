package model;

public class Model {

    public Model() {


    }

}
